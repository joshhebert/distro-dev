#ifndef _SYS_USER_H
#define _SYS_USER_H
#ifdef __cplusplus
extern "C" {
#endif

#include <limits.h>
#include <stdint.h>
#include <unistd.h>

#include <bits/user.h>

#ifdef __cplusplus
}
#endif
#endif
